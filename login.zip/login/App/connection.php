<?php 

    //connecting to database

    $server = "localhost";
    $username  = "root";   //default xamp username is root online changes
    $password  = "";        //default inside xamp with no password
    $database  = "students"; 

        // con > connecction 
        // new mysqli or mysqli_connect
    $con = mysqli_connect($server , $username , $password , $database);
    if (!$con) {
        echo "Connection Failed";
    }