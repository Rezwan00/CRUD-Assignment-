<?php 
    require_once 'connection.php';

    $name = $_POST['name'];
    $email = $_POST['email'];
    $pass  = $_POST['password'];
    
    $sql = "INSERT INTO users VALUES(NULL , '$name', '$email' , '$pass', curdate())";
    $result = $con->query($sql);
    if ($result){
        echo 1;
    }else{
        echo 0;
    }
