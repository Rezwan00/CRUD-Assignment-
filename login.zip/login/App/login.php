<?php 
    session_start();
    require_once 'connection.php';

    $username = $_POST['username'];
    $password = $_POST['password'];

    $sql = "SELECT * FROM users WHERE email = '$username' AND password = '$password'";
    $result = $con->query($sql);
    
    if ($result->num_rows == 1){
        $user = $result->fetch_assoc();
        $_SESSION['user'] = $user;
        echo 1;
    }else{
        echo 2;
    }