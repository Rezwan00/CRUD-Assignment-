<?php
require_once 'connection.php';

$firstname = $_POST['firstname'];
$lastname = $_POST['lastname'];
$fathername = $_POST['fathername'];
$dob = $_POST['dob'];
$course = $_POST['course'];

$sql = "INSERT INTO students
    VALUES(NULL , '$firstname', '$lastname' , '$fathername', '$dob' ,
    '$course' , curdate() , curdate())";
$result = $con->query($sql);
if ($result) {
    echo 1;
} else {
    echo 0;
}
