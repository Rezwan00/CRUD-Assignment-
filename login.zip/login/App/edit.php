<?php 

    $id = $_GET['id'];
    require_once 'connection.php';
    $sql = "SELECT * FROM students WHERE id = ".$id;
    $result = $con->query($sql);
    $row = $result->fetch_assoc();
    echo json_encode($row);

