<?php 
    session_start();
    require_once 'connection.php';
    $sql = "SELECT * FROM students ORDER BY id DESC";
    $result = $con->query($sql);
    $data = "";
    while ($rows = $result->fetch_assoc()){
        $data .= "
            <tr id='tr".$rows['id']."'>
                <td>".$rows['id']."</td>
                <td>".$rows['firstname']."</td>
                <td>".$rows['lastname']."</td>
                <td>".$rows['fathername']."</td>
                <td>".$rows['dob']."</td>
                <td>".$rows['course']."</td>
                <td>".$rows['created']."</td>
                <td>".$rows['updated']."</td>
                <td>
                    <a class='edit-btn' onclick='handleEdit(".$rows['id'].")'>Edit</a>
                </td>
                <td>
                    <a onclick='handleDelete(".$rows['id'].")' class='delete-btn'>Delete</a>
                </td>
            </tr>
        ";
    }

    echo $data;