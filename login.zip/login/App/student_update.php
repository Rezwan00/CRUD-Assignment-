<?php
require_once 'connection.php';

$id = $_POST['id'];
$firstname = $_POST['firstname'];
$lastname = $_POST['lastname'];
$fathername = $_POST['fathername'];
$dob = $_POST['dob'];
$course = $_POST['course'];

$sql = "UPDATE students
    SET firstname ='$firstname', lastname = '$lastname' , fathername ='$fathername', dob = '$dob' ,
    course = '$course' , updated = curdate() WHERE id = " . $id;
$result = $con->query($sql);
if ($result) {
    echo 1;
} else {
    echo 0;
}
