<!-- Links Section -->
<?php include_once 'components/links.php' ?>

<!-- Table Section -->
<?php include_once 'components/table.php' ?>

<!-- Modal Section -->
<?php include_once 'components/modal.php' ?>

<!-- Login Section -->
<?php include_once 'components/login.php' ?>

<script>
	handleLogin = () => {
		let username = $("#login_username").val();
		let password = $("#login_password").val();
		const isValid = validateLogin(username, password);
		isValid ?
			$.ajax({
				url: "App/login.php",
				method: 'POST',
				data: {
					username: username,
					password: password
				},
				success: function(data) {
					if (data == 1) {
						$("#login").css("display", "none");
						$("#dashboard").css("display", "block");
						$("#msg").css("display", "block");
						$("#msg").text("Welcome to Dashboard");
						setTimeout(() => {
							$("#msg").slideUp(1000);
						}, 1000);
					} else {
						$("#lmsg").css("display", "block");
						$("#lmsg").text("Incorrect Username or Password");
						setTimeout(() => {
							$("#lmsg").slideUp(1000);
						}, 1000);
					}
				},
			}) : null;
	}

	registerUser = () => {
		let name = $("#register_name").val();
		let email = $("#register_email").val();
		let pass = $("#register_password").val();

		const isValid = validateRegister(name, email, pass);
		isValid ?
			$.ajax({
				url: "App/register.php",
				method: 'POST',
				data: {
					name: name,
					email: email,
					password: pass,
				},
				success: function(data) {
					if (data == 1) {
						$("#rmsg").css("display", "block");
						$("#rmsg").text("Account Created Successfully");
						setTimeout(() => {
							$("#rmsg").slideUp(1000);
						}, 1000);
					}
				},
			}) : null;
	}

	getStudentList = () => {
		$.ajax({
			url: "App/student_list.php",
			method: 'GET',
			success: function(data) {
				$("#data").html(data);
			},
		});
	}

	registerStudent = () => {
		let firstname = $("#firstname").val();
		let lastname = $("#lastname").val();
		let fathername = $("#fathername").val();
		let dob = $("#dob").val();
		let course = $("#course").val();

		const isStudentValid = validateStudent(firstname, lastname, fathername, dob, course);
		isStudentValid ?
			$.ajax({
				url: "App/student_register.php",
				method: 'POST',
				data: {
					firstname: firstname,
					lastname: lastname,
					fathername: fathername,
					dob: dob,
					course: course
				},
				success: function(data) {
					getStudentList();
					$("#myModal").slideUp(1000);
					$("#firstname").val("");
					$("#lastname").val("");
					$("#fathername").val("");
					$("#dob").val("");
					$("#course").val("");
					$("#msg").css("display", "block");
					$("#msg").text("Student Registerd Successfully");
					setTimeout(() => {
						$("#msg").slideUp(1000);
					}, 2000);
				},
			}) : null;
	}

	handleEdit = id => {
		$.ajax({
			url: "App/edit.php?id=" + id,
			method: 'GET',
			success: function(data) {
				$("#myModal").slideDown(1000);
				const obj = JSON.parse(data);
				$("#st_id").val(obj.id);
				$("#firstname").val(obj.firstname);
				$("#lastname").val(obj.lastname);
				$("#fathername").val(obj.fathername);
				$("#dob").val(obj.dob);
				$("#course").val(obj.course);
				$("#update").css('display', "block");
				$("#register").css('display', "none");
			},
		});
	}

	updateStudent = () => {
		let id = $("#st_id").val();
		let firstname = $("#firstname").val();
		let lastname = $("#lastname").val();
		let fathername = $("#fathername").val();
		let dob = $("#dob").val();
		let course = $("#course").val();

		const isStudentValid = validateStudent(firstname, lastname, fathername, dob, course);
		isStudentValid ?
			$.ajax({
				url: "App/student_update.php",
				method: 'POST',
				data: {
					id: id,
					firstname: firstname,
					lastname: lastname,
					fathername: fathername,
					dob: dob,
					course: course
				},
				success: function(data) {
					getStudentList();
					$("#myModal").slideUp(1000);
					$("#firstname").val("");
					$("#lastname").val("");
					$("#fathername").val("");
					$("#dob").val("");
					$("#course").val("");
					$("#msg").html("Student Updated Successfully");
					$("msg").slideUp(1000);
				},
			}) : null;
	}


	handleDelete = id => {
		let ans = confirm("Are you Sure?");
		if (ans) {
			$.ajax({
				url: "App/delete.php?id=" + id,
				method: 'GET',
				success: function(data) {
					$("#tr" + data).css("display", "none");
				},
			});
		}
	}

	logout = () => {
		$.ajax({
			url: "App/logout.php",
			method: 'GET',
			success: function(data) {
				if (data == 1) {
					$("#login").css("display", "block");
					$("#dashboard").css("display", "none");
					$("#login_username").val("");
					$("#login_password").val("");
					$("#register_name").val("");
					$("#register_email").val("");
					$("#register_password").val("");
				}
			},
		});
	}

	// Show Students List
	getStudentList();

	openModal = () => {
		$("#firstname").val("");
		$("#lastname").val("");
		$("#fathername").val("");
		$("#dob").val("");
		$("#course").val("");
		$("#myModal").css("display", "block");
		$("#register").css("display", "block");
		$("#update").css("display", "none");
	}

	let modal = document.getElementById('myModal');
	let span = document.getElementsByClassName("close")[0];
	span.onclick = function() {
		modal.style.display = "none";
	}

	// When the user clicks anywhere outside of the modal, close it
	window.onclick = function(event) {
		if (event.target == modal) {
			modal.style.display = "none";
		}
	}

	// Validations
	validateLogin = (username, password) => {
		let result = true;
		if (username == "") {
			$("#umsg").text("Please Enter Your Email");
			result = false;
		} else {
			$("#umsg").text("");
			result = true;
		}

		if (password == "") {
			$("#pmsg").text("Please Enter Your Password");
			result = false;
		} else {
			$("#pmsg").text("");
			result = true;
		}
		return result;
	}

	validateRegister = (name, username, password) => {
		let result = true;
		if (name == "") {
			$("#nmsg").text("Please Enter Your Name");
			result = false;
		} else {
			$("#nmsg").text("");
			result = true;
		}

		if (username == "") {
			$("#emsg").text("Please Enter Your Email");
			result = false;
		} else {
			$("#emsg").text("");
			result = true;
		}

		if (password == "") {
			$("#rpmsg").text("Please Enter Your Password");
			result = false;
		} else {
			$("#rpmsg").text("");
			result = true;
		}
		return result;
	}

	validateStudent = (firstname, lastname, fathername, dob, course) => {
		let result = true;
		if (firstname == "") {
			$("#fmsg").text("Please Enter Firstname");
			result = false;
		} else {
			$("#fmsg").text("");
			result = true;
		}

		if (lastname == "") {
			$("#lmmsg").text("Please Enter Lastname");
			result = false;
		} else {
			$("#lmmsg").text("");
			result = true;
		}

		if (fathername == "") {
			$("#famsg").text("Please Enter Father");
			result = false;
		} else {
			$("#famsg").text("");
			result = true;
		}

		if (dob == "") {
			$("#dmsg").text("Please Enter Date Of Birth");
			result = false;
		} else {
			$("#dmsg").text("");
			result = true;
		}

		if (course == "") {
			$("#cmsg").text("Please Enter Course");
			result = false;
		} else {
			$("#cmsg").text("");
			result = true;
		}

		return result;
	}
</script>