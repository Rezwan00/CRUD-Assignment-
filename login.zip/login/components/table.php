<div class="table-container" id="dashboard" style="display: none; margin-top:-250px ;">
    <div class="msg" id="msg"></div>
    <h1 class="heading"> Student Dashboard</h1>
    <button id="myBtn" onclick="openModal()" class="add">Add New</button>
    <button onclick="logout()" class="add" style="float: right;background-color: tomato;">Logout</button>
    <table class="table">
        <thead>
            <tr>
                <th>ID</th>
                <th>First Name</th>
                <th>Last Name</th>
                <th>Father Name</th>
                <th>Dob</th>
                <th>Course</th>
                <th>Created</th>
                <th>updated</th>
                <th>Edit</th>
                <th>Delete</th>
            </tr>
        </thead>
        <tbody id="data">
        </tbody>
    </table>
</div>