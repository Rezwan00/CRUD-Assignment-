<div id="myModal" class="modal">
    <div class="modal-content">
        <span onclick="close()" class="close">&times;</span>
        <div>
            <input type="hidden" name="id" id="st_id">
            <div class="form-group">
                <label for="firstname">Firstname</label>
                <input type="text" id="firstname" placeholder="First Name">
            </div>
            <div class="text-danger" id="fmsg"></div>
            <div class="form-group">
                <label for="lastname">Lastname</label>
                <input type="text" id="lastname" placeholder="Last Name">
            </div>
            <div class="text-danger" id="lmmsg"></div>

            <div class="form-group">
                <label for="fathername">Father Name</label>
                <input type="text" id="fathername" placeholder="Father Name">
            </div>
            <div class="text-danger" id="famsg"></div>

            <div class="form-group">
                <label for="dob">Date of Birth</label>
                <input type="date" id="dob">
            </div>
            <div class="text-danger" id="dmsg"></div>

            <div class="form-group">
                <label for="course">Course</label>
                <input type="text" id="course" placeholder="Course">
            </div>
            <div class="text-danger" id="cmsg"></div>

            <div class="form-group">
                <button class="btn" id="register" onclick="registerStudent()">
                    Register
                </button>
                <button class="btn" id="update" onclick="updateStudent()" style="display: none;">
                    Update
                </button>
            </div>
        </div>
    </div>
</div>