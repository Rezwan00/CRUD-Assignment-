<div class="container .main" id="login">
		<input type="checkbox" id="flip">
		<div class="cover">
			<div class="front">
				<img src="img/login.jpg" alt="">
			</div>
		</div>
		<form action="#">
			<div class="form-content">
				<div class="login-form">
					<div class="title">Login</div>
					<form action="" class="login_form">
						<div class="input-boxes">
							<div class="input-box">
								<i class="fas fa-envelope"> </i>
								<input type="email" id="login_username" placeholder="Enter your email" required>
							</div>
							<div class="text-danger" id="umsg"></div>

							<div class="input-box">
								<i class="fas fa-lock"> </i>
								<input type="password" id="login_password" placeholder="Enter your password" required>
							</div>
							<div class="text-danger" id="pmsg"></div>

							<div class="text"> <a href="#"> Forgot password?</a> </div>
							<div class="button input-box">
								<input type="button" onclick="handleLogin()" value="Sign In">
							</div>
							<div class="text">Don't have an account? <label for="flip">Signup now </label> </div>
							<div class="register_msg" id="lmsg">
							</div>
						</div>
					</form>
				</div>
				<!-- 	Sign Up  Form -->
				<div class="Signup-form">
					<div class="title">Sign Up</div>
					<div class="input-boxes">
						<div class="input-box">
							<i class="fas fa-user"> </i>
							<input type="text" id="register_name" placeholder="Enter your name" required>
						</div>
						<div class="text-danger" id="nmsg"></div>

						<div class="input-box">
							<i class="fas fa-envelope"> </i>
							<input type="text" id="register_email" placeholder="Enter your email" required>
						</div>
						<div class="text-danger" id="emsg"></div>

						<div class="input-box">
							<i class="fas fa-lock"> </i>
							<input type="password" id="register_password" placeholder="Enter your password" required>
						</div>
						<div class="text-danger" id="rpmsg"></div>

						<div class="button input-box">
							<input type="button" value="Register" onclick="registerUser()">
						</div>
						<div class="text">Already have an account? <label for="flip">Login now </label> </div>
						<div class="register_msg" id="rmsg">

						</div>
					</div>
				</div>
			</div>
		</form>
</div>